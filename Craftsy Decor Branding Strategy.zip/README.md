
  # Craftsy Decor Branding Strategy

  This is a code bundle for Craftsy Decor Branding Strategy. The original project is available at https://www.figma.com/design/ct4Wi7fLGPbEz8imzpCX2J/Craftsy-Decor-Branding-Strategy.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  