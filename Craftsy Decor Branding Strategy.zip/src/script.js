// Shopping Cart State
let cart = {
    items: [],
    totalItems: 0,
    totalPrice: 0
};

// DOM Elements
const cartBadge = document.getElementById('cartBadge');
const cartDrawer = document.getElementById('cartDrawer');
const cartItems = document.getElementById('cartItems');
const cartTotal = document.getElementById('cartTotal');

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    updateCartUI();
    
    // Add smooth scrolling to all internal links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Add form submission handler
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactForm);
    }

    // Add newsletter subscription handler
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', handleNewsletterSubscription);
    }
});

// Smooth scroll functions
function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
            inline: 'nearest'
        });
    }
}

// Cart Functions
function toggleCart() {
    cartDrawer.classList.toggle('open');
}

function addToCart(id, name, price, artisan, category, image) {
    // Check if item already exists
    const existingItem = cart.items.find(item => item.id === id);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.items.push({
            id,
            name,
            price,
            priceNumeric: price,
            artisan,
            category,
            image,
            quantity: 1
        });
    }
    
    updateCartState();
    updateCartUI();
    showToast(`${name} added to cart!`, `by ${artisan}`, 'success');
    
    // Update button state temporarily
    const button = document.querySelector(`[onclick*="addToCart(${id}"]`);
    if (button) {
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-check"></i> Added';
        button.classList.add('added');
        button.disabled = true;
        
        setTimeout(() => {
            button.innerHTML = originalText;
            button.classList.remove('added');
            button.disabled = false;
        }, 2000);
    }
}

function removeFromCart(id) {
    cart.items = cart.items.filter(item => item.id !== id);
    updateCartState();
    updateCartUI();
}

function updateCartState() {
    cart.totalItems = cart.items.reduce((total, item) => total + item.quantity, 0);
    cart.totalPrice = cart.items.reduce((total, item) => total + (item.priceNumeric * item.quantity), 0);
}

function updateCartUI() {
    // Update badge
    cartBadge.textContent = cart.totalItems;
    cartBadge.style.display = cart.totalItems > 0 ? 'flex' : 'none';
    
    // Update cart items
    if (cart.items.length === 0) {
        cartItems.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
    } else {
        cartItems.innerHTML = cart.items.map(item => `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                <div class="cart-item-info">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-artisan">by ${item.artisan}</div>
                    <div class="cart-item-price">₹${item.priceNumeric} × ${item.quantity}</div>
                </div>
                <button onclick="removeFromCart(${item.id})" class="remove-item-btn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `).join('');
    }
    
    // Update total
    cartTotal.textContent = cart.totalPrice.toLocaleString();
}

// Toast Notification
function showToast(title, description = '', type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    toast.innerHTML = `
        <div>
            <div style="font-weight: 500; margin-bottom: 0.25rem;">${title}</div>
            ${description ? `<div style="font-size: 0.875rem; color: #6b7280;">${description}</div>` : ''}
        </div>
        <button onclick="this.parentElement.remove()" style="background: none; border: none; font-size: 1.25rem; cursor: pointer; color: #6b7280;">×</button>
    `;
    
    document.body.appendChild(toast);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (toast.parentElement) {
            toast.remove();
        }
    }, 3000);
}

// Form Handlers
function handleContactForm(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData);
    
    // Simulate form submission
    showToast('Message sent successfully!', 'We\'ll get back to you soon.', 'success');
    e.target.reset();
}

function handleNewsletterSubscription(e) {
    e.preventDefault();
    
    const email = e.target.querySelector('input[type="email"]').value;
    
    if (email) {
        // Simulate subscription
        showToast('Successfully subscribed!', `We'll send updates to ${email}`, 'success');
        e.target.reset();
    }
}

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('fade-in');
        }
    });
}, observerOptions);

// Observe elements for animation
document.addEventListener('DOMContentLoaded', () => {
    const elementsToAnimate = document.querySelectorAll(
        '.product-card, .artisan-card, .impact-card, .timeline-item, .feature-item, .plan-card'
    );
    
    elementsToAnimate.forEach(el => {
        observer.observe(el);
    });
});

// Mobile Menu Toggle (if needed)
function toggleMobileMenu() {
    const nav = document.querySelector('.nav-mobile');
    // Implementation for mobile menu if needed
}

// Wishlist functionality (placeholder)
function toggleWishlist(productId) {
    // Placeholder for wishlist functionality
    showToast('Added to wishlist!', '', 'success');
}

// QR Code functionality (placeholder)
function showQRCode(productId) {
    // Placeholder for QR code functionality
    showToast('QR Code feature coming soon!', '', 'success');
}

// Plan selection
function selectPlan(planName, price) {
    showToast(`${planName} plan selected!`, `₹${price}/month`, 'success');
}

// Prevent form submission on newsletter
document.addEventListener('DOMContentLoaded', function() {
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleNewsletterSubscription(e);
        });
    }
});

// Add click handlers for plan buttons
document.addEventListener('DOMContentLoaded', function() {
    const planButtons = document.querySelectorAll('.plan-card .btn');
    planButtons.forEach((button, index) => {
        const plans = [
            { name: 'Essential', price: 799 },
            { name: 'Premium', price: 1299 },
            { name: 'Collector', price: 1999 }
        ];
        
        if (plans[index]) {
            button.addEventListener('click', () => {
                selectPlan(plans[index].name, plans[index].price);
            });
        }
    });
});

// Smooth reveal animations on scroll
function revealOnScroll() {
    const reveals = document.querySelectorAll('.product-card, .artisan-card, .impact-card');
    
    reveals.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;
        
        if (elementTop < window.innerHeight - elementVisible) {
            element.classList.add('fade-in');
        }
    });
}

window.addEventListener('scroll', revealOnScroll);

// Header scroll effect
window.addEventListener('scroll', function() {
    const header = document.querySelector('.header');
    if (window.scrollY > 100) {
        header.style.boxShadow = '0 2px 20px rgba(0,0,0,0.1)';
    } else {
        header.style.boxShadow = '0 1px 3px 0 rgba(0, 0, 0, 0.1)';
    }
});

// Close cart when clicking outside
document.addEventListener('click', function(e) {
    if (cartDrawer.classList.contains('open') && 
        !cartDrawer.querySelector('.cart-content').contains(e.target) &&
        !e.target.closest('.cart-btn')) {
        toggleCart();
    }
});

// Close cart with Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && cartDrawer.classList.contains('open')) {
        toggleCart();
    }
});

// Add loading states for buttons
function addLoadingState(button, originalText, loadingText = 'Loading...') {
    button.disabled = true;
    button.innerHTML = loadingText;
    
    setTimeout(() => {
        button.disabled = false;
        button.innerHTML = originalText;
    }, 1000);
}

// Initialize tooltips or other interactive elements
document.addEventListener('DOMContentLoaded', function() {
    // Add hover effects for product cards
    const productCards = document.querySelectorAll('.product-card');
    productCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // Add hover effects for artisan cards
    const artisanCards = document.querySelectorAll('.artisan-card');
    artisanCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-4px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});

// Analytics placeholders (for future implementation)
function trackEvent(eventName, properties = {}) {
    console.log('Analytics Event:', eventName, properties);
    // Implementation for analytics tracking
}

// Track cart events
function trackCartEvent(action, item) {
    trackEvent(`cart_${action}`, {
        item_id: item.id,
        item_name: item.name,
        price: item.priceNumeric,
        artisan: item.artisan
    });
}

// Accessibility improvements
document.addEventListener('DOMContentLoaded', function() {
    // Add focus styles for keyboard navigation
    const focusableElements = document.querySelectorAll('button, a, input, textarea, select');
    
    focusableElements.forEach(element => {
        element.addEventListener('focus', function() {
            this.style.outline = '2px solid var(--primary)';
            this.style.outlineOffset = '2px';
        });
        
        element.addEventListener('blur', function() {
            this.style.outline = 'none';
        });
    });
});

// Performance optimization - Lazy loading for images
document.addEventListener('DOMContentLoaded', function() {
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        imageObserver.unobserve(img);
                    }
                }
            });
        });

        const lazyImages = document.querySelectorAll('img[data-src]');
        lazyImages.forEach(img => imageObserver.observe(img));
    }
});