import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Recycle, Leaf, Users, Award } from "lucide-react";

const impacts = [
  {
    icon: Recycle,
    title: "Zero Waste Production",
    description: "All our products are made from upcycled materials or sustainably sourced resources.",
    metric: "100%",
    label: "Eco-Friendly"
  },
  {
    icon: Users,
    title: "Community Empowerment",
    description: "Supporting 500+ artisans across India, including differently-abled creators.",
    metric: "500+",
    label: "Artisans"
  },
  {
    icon: Leaf,
    title: "Carbon Neutral Shipping",
    description: "Eco-friendly packaging and carbon-neutral delivery to your doorstep.",
    metric: "0kg",
    label: "Carbon Footprint"
  },
  {
    icon: Award,
    title: "Fair Trade Certified",
    description: "Ensuring fair wages and ethical working conditions for all our partner artisans.",
    metric: "100%",
    label: "Fair Trade"
  }
];

export function SustainabilitySection() {
  return (
    <section id="sustainability" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4 bg-accent text-foreground">
            From Waste to Wow
          </Badge>
          <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">
            Sustainability at Our Core
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Every purchase you make creates a positive ripple effect. From empowering artisan communities 
            to reducing environmental impact, your choice makes a difference.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {impacts.map((impact, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow bg-gradient-to-br from-white to-secondary">
              <CardContent className="p-6">
                <div className="flex justify-center mb-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                    <impact.icon className="w-6 h-6 text-primary" />
                  </div>
                </div>
                <div className="text-3xl text-primary mb-2">{impact.metric}</div>
                <div className="text-xs text-muted-foreground mb-3">{impact.label}</div>
                <h3 className="text-lg mb-2 text-foreground">{impact.title}</h3>
                <p className="text-sm text-muted-foreground">{impact.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Timeline */}
        <div className="bg-secondary rounded-2xl p-8">
          <h3 className="text-2xl text-center mb-8 text-foreground">Our Impact Journey</h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white">2023</span>
              </div>
              <h4 className="mb-2 text-foreground">Foundation</h4>
              <p className="text-sm text-muted-foreground">
                Started with 50 artisans and a vision for sustainable living
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white">2024</span>
              </div>
              <h4 className="mb-2 text-foreground">Growth</h4>
              <p className="text-sm text-muted-foreground">
                Expanded to 500+ artisans across 15 states
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white">2025</span>
              </div>
              <h4 className="mb-2 text-foreground">Future</h4>
              <p className="text-sm text-muted-foreground">
                Global expansion and 1000+ empowered artisans
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}