import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Box, Calendar, Star, Gift } from "lucide-react";

const subscriptionPlans = [
  {
    name: "Seasonal Surprise",
    price: "₹1,999",
    period: "quarterly",
    description: "Curated seasonal décor pieces delivered every 3 months",
    features: [
      "3-4 handcrafted items",
      "Artisan story cards",
      "Seasonal styling guide",
      "Free shipping",
      "QR code authenticity"
    ],
    badge: "Most Popular"
  },
  {
    name: "Monthly Craft Kit",
    price: "₹799",
    period: "monthly",
    description: "DIY craft kits to create beautiful décor at home",
    features: [
      "Complete craft materials",
      "Video tutorials",
      "Artisan technique guide",
      "Community access",
      "Monthly virtual workshop"
    ],
    badge: ""
  },
  {
    name: "Annual Collection",
    price: "₹6,999",
    period: "yearly",
    description: "Premium collection with exclusive artisan collaborations",
    features: [
      "12 premium items",
      "Exclusive designs",
      "Artisan meet & greets",
      "Priority customization",
      "Anniversary gifts"
    ],
    badge: "Best Value"
  }
];

export function SubscriptionSection() {
  return (
    <section id="subscription" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4 bg-accent text-foreground">
            <Box className="w-4 h-4 mr-1" />
            Subscription Boxes
          </Badge>
          <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">
            Discover Something New Every Month
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Bring the joy of discovery to your doorstep with carefully curated collections. 
            Each box tells a story and supports artisan communities worldwide.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {subscriptionPlans.map((plan, index) => (
            <Card key={index} className={`relative overflow-hidden hover:shadow-lg transition-shadow ${plan.badge === 'Most Popular' ? 'ring-2 ring-primary' : ''}`}>
              {plan.badge && (
                <div className="absolute top-4 right-4">
                  <Badge className="bg-primary text-white">
                    {plan.badge}
                  </Badge>
                </div>
              )}
              
              <CardHeader className="pb-4">
                <h3 className="text-xl mb-2 text-foreground">{plan.name}</h3>
                <div className="flex items-baseline space-x-1 mb-3">
                  <span className="text-3xl text-primary">{plan.price}</span>
                  <span className="text-muted-foreground">/{plan.period}</span>
                </div>
                <p className="text-sm text-muted-foreground">{plan.description}</p>
              </CardHeader>
              
              <CardContent className="pt-0">
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-sm">
                      <Star className="w-4 h-4 text-primary mr-3 flex-shrink-0" />
                      <span className="text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className={`w-full ${plan.badge === 'Most Popular' ? 'bg-primary hover:bg-primary/90' : ''}`}
                  variant={plan.badge === 'Most Popular' ? 'default' : 'outline'}
                >
                  {plan.badge === 'Most Popular' ? 'Start Subscription' : 'Choose Plan'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Unboxing Experience */}
        <div className="bg-gradient-to-br from-secondary to-accent rounded-2xl p-8">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl mb-4 text-foreground">
                <Gift className="w-6 h-6 inline mr-2" />
                The Unboxing Experience
              </h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-center">
                  <Calendar className="w-4 h-4 text-primary mr-3" />
                  Delivered on the 15th of every month
                </li>
                <li className="flex items-center">
                  <Box className="w-4 h-4 text-primary mr-3" />
                  Eco-friendly packaging with care
                </li>
                <li className="flex items-center">
                  <Star className="w-4 h-4 text-primary mr-3" />
                  QR codes link to artisan stories
                </li>
              </ul>
              <Button className="mt-6 bg-primary hover:bg-primary/90">
                Watch Unboxing Video
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-4 text-center shadow-sm">
                <div className="text-2xl text-primary mb-1">500+</div>
                <div className="text-xs text-muted-foreground">Happy Subscribers</div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center shadow-sm">
                <div className="text-2xl text-primary mb-1">4.9★</div>
                <div className="text-xs text-muted-foreground">Average Rating</div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center shadow-sm">
                <div className="text-2xl text-primary mb-1">50+</div>
                <div className="text-xs text-muted-foreground">Artisan Partners</div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center shadow-sm">
                <div className="text-2xl text-primary mb-1">100%</div>
                <div className="text-xs text-muted-foreground">Satisfaction</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}