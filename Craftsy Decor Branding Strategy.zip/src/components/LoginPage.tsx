import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Separator } from "./ui/separator";
import { Alert, AlertDescription } from "./ui/alert";
import { Eye, EyeOff, Mail, Lock, User, Leaf, Heart, AlertCircle } from "lucide-react";
import { authService } from "../utils/auth-mock";
import { cartService } from "../utils/cart-mock";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface LoginPageProps {
  onLoginSuccess: () => void;
}

export function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: ""
  });

  // Check for existing session on mount
  useEffect(() => {
    checkExistingSession();
  }, []);

  const checkExistingSession = async () => {
    const { user, session, error } = await authService.getCurrentSession();
    if (user && session && !error) {
      await cartService.syncCartAfterLogin();
      onLoginSuccess();
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError(""); // Clear error when user types
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      if (isSignUp) {
        if (!formData.name.trim()) {
          setError("Name is required");
          setLoading(false);
          return;
        }

        const { user, session, error } = await authService.signUp({
          email: formData.email,
          password: formData.password,
          name: formData.name
        });

        if (error) {
          setError(error);
        } else if (user && session) {
          await cartService.syncCartAfterLogin();
          onLoginSuccess();
        }
      } else {
        const { user, session, error } = await authService.signIn({
          email: formData.email,
          password: formData.password
        });

        if (error) {
          setError(error);
        } else if (user && session) {
          await cartService.syncCartAfterLogin();
          onLoginSuccess();
        }
      }
    } catch (error) {
      setError("An unexpected error occurred. Please try again.");
      console.error("Auth error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError("");

    try {
      const { error } = await authService.signInWithGoogle();
      if (error) {
        setError(`Google login error: ${error}. Please ensure Google OAuth is configured in your Supabase project.`);
      }
      // Note: Google OAuth redirect will handle success case
    } catch (error) {
      setError("Failed to connect with Google. Please try again.");
      console.error("Google auth error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1756284816902-a1dfb0ea4a5e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlY28lMjBmcmllbmRseSUyMG5hdHVyYWwlMjBsZWF2ZXMlMjB0ZXh0dXJlfGVufDF8fHx8MTc1OTIyMTk5MXww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Natural eco-friendly background"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-green-50/90 via-orange-50/90 to-amber-50/90"></div>
      </div>

      {/* Main Content */}
      <Card className="w-full max-w-md relative z-10 shadow-2xl border-0 bg-white/95 backdrop-blur-sm">
        <CardHeader className="text-center space-y-6 pb-6">
          {/* Logo */}
          <div className="flex items-center justify-center space-x-2">
            <div className="relative">
              <Heart className="w-10 h-10 text-primary" fill="currentColor" />
              <Leaf className="w-4 h-4 text-green-600 absolute -top-1 -right-1" />
            </div>
            <div className="text-center">
              <h1 className="text-2xl font-medium text-foreground">Craftsy Decor</h1>
              <p className="text-xs text-muted-foreground font-normal">Handmade with Heart, Delivered with Care</p>
            </div>
          </div>

          {/* Welcome Text */}
          <div>
            <h2 className="text-xl font-medium text-foreground mb-2">
              {isSignUp ? "Join Our Community" : "Welcome to Craftsy Decor"}
            </h2>
            <p className="text-sm text-muted-foreground">
              {isSignUp 
                ? "Discover authentic handicrafts from skilled artisans" 
                : "Sign in to explore authentic handicrafts"
              }
            </p>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Error Alert */}
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Name Field (Sign Up Only) */}
            {isSignUp && (
              <div className="space-y-2">
                <Label htmlFor="name" className="text-foreground flex items-center space-x-2">
                  <User className="w-4 h-4" />
                  <span>Full Name</span>
                </Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Enter your full name"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  className="h-12 rounded-xl shadow-sm border-border focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
                  required={isSignUp}
                  disabled={loading}
                />
              </div>
            )}

            {/* Email Field */}
            <div className="space-y-2">
              <Label htmlFor="email" className="text-foreground flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span>Email Address</span>
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                className="h-12 rounded-xl shadow-sm border-border focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
                required
                disabled={loading}
              />
            </div>

            {/* Password Field */}
            <div className="space-y-2">
              <Label htmlFor="password" className="text-foreground flex items-center space-x-2">
                <Lock className="w-4 h-4" />
                <span>Password</span>
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder={isSignUp ? "Create a password" : "Enter your password"}
                  value={formData.password}
                  onChange={(e) => handleInputChange("password", e.target.value)}
                  className="h-12 rounded-xl shadow-sm border-border focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all pr-12"
                  required
                  disabled={loading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  disabled={loading}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Forgot Password (Login Only) */}
            {!isSignUp && (
              <div className="text-right">
                <button
                  type="button"
                  className="text-sm text-primary hover:text-primary/80 transition-colors hover:underline"
                  disabled={loading}
                >
                  Forgot password?
                </button>
              </div>
            )}

            {/* Submit Button */}
            <Button 
              type="submit" 
              className="w-full h-12 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg hover:shadow-xl transition-all transform hover:scale-[1.02] disabled:transform-none"
              disabled={loading}
            >
              {loading ? (
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>{isSignUp ? "Creating Account..." : "Signing In..."}</span>
                </div>
              ) : (
                isSignUp ? "Create Account" : "Sign In"
              )}
            </Button>
          </form>

          {/* Divider */}
          <div className="relative">
            <Separator className="bg-border/50" />
            <span className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white px-3 text-xs text-muted-foreground uppercase tracking-wider">
              OR CONTINUE WITH
            </span>
          </div>

          {/* Google Login */}
          <Button
            type="button"
            variant="outline"
            onClick={handleGoogleLogin}
            className="w-full h-12 rounded-xl border-border hover:bg-secondary shadow-sm hover:shadow-md transition-all transform hover:scale-[1.02] disabled:transform-none"
            disabled={loading}
          >
            <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24" fill="none">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Continue with Google
          </Button>

          {/* Toggle Sign Up/Sign In */}
          <div className="text-center space-y-4">
            <p className="text-sm text-muted-foreground">
              {isSignUp ? "Already have an account?" : "Don't have an account?"}{" "}
              <button
                type="button"
                onClick={() => {
                  setIsSignUp(!isSignUp);
                  setError("");
                  setFormData({ name: "", email: "", password: "" });
                }}
                className="text-primary hover:text-primary/80 transition-colors font-medium hover:underline"
                disabled={loading}
              >
                {isSignUp ? "Sign in" : "Sign up"}
              </button>
            </p>

            {/* Eco Badges */}
            <div className="flex justify-center space-x-2 pt-2">
              <div className="flex items-center space-x-1 text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full">
                <Leaf className="w-3 h-3" />
                <span>Eco-Friendly</span>
              </div>
              <div className="flex items-center space-x-1 text-xs text-orange-600 bg-orange-50 px-2 py-1 rounded-full">
                <Heart className="w-3 h-3" />
                <span>Artisan Made</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Footer */}
      <div className="absolute bottom-4 left-0 right-0 text-center z-10">
        <p className="text-xs text-muted-foreground mb-2">
          Crafted with ❤️ by Craftsy Decor
        </p>
        <div className="flex justify-center space-x-4">
          <button className="text-xs text-muted-foreground hover:text-foreground transition-colors hover:underline">
            Privacy Policy
          </button>
          <button className="text-xs text-muted-foreground hover:text-foreground transition-colors hover:underline">
            Terms of Use
          </button>
        </div>
      </div>
    </div>
  );
}