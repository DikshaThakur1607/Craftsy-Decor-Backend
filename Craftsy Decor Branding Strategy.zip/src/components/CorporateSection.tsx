import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Building2, Gift, Users, Target } from "lucide-react";

const corporateServices = [
  {
    icon: Gift,
    title: "Employee Gifting",
    description: "Meaningful corporate gifts that reflect your company's values and support artisan communities.",
    features: ["Custom packaging", "Bulk discounts", "QR code stories", "CSR impact reports"]
  },
  {
    icon: Building2,
    title: "Office Décor",
    description: "Transform your workspace with sustainable, handcrafted pieces that inspire creativity and wellness.",
    features: ["Space consultation", "Custom installations", "Maintenance support", "Quarterly updates"]
  },
  {
    icon: Users,
    title: "Team Building Workshops",
    description: "Engage your team with hands-on crafting workshops led by our partner artisans.",
    features: ["Virtual & in-person", "Skill development", "Cultural exchange", "Take-home crafts"]
  },
  {
    icon: Target,
    title: "CSR Partnerships",
    description: "Partner with us to create meaningful CSR programs that directly impact artisan communities.",
    features: ["Impact measurement", "Storytelling content", "Employee engagement", "Tax benefits"]
  }
];

export function CorporateSection() {
  return (
    <section id="corporate" className="py-16 bg-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4 bg-white text-foreground">
            Corporate Solutions
          </Badge>
          <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">
            Partner with Purpose
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Create meaningful corporate experiences while supporting artisan communities. 
            Our B2B solutions help your business make a positive social and environmental impact.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {corporateServices.map((service, index) => (
            <Card key={index} className="bg-white hover:shadow-lg transition-shadow">
              <CardHeader className="pb-4">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <service.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-xl text-foreground">{service.title}</h3>
                </div>
                <p className="text-muted-foreground">{service.description}</p>
              </CardHeader>
              
              <CardContent className="pt-0">
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button variant="outline" className="w-full">
                  Learn More
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-primary to-primary/90 rounded-2xl p-8 text-center text-white">
          <h3 className="text-2xl mb-4">Ready to Make an Impact?</h3>
          <p className="text-lg mb-6 text-white/90 max-w-2xl mx-auto">
            Join leading companies in creating positive change through thoughtful corporate partnerships. 
            Let's discuss how we can customize solutions for your business needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary">
              Schedule Consultation
            </Button>
            <Button size="lg" variant="outline" className="bg-transparent border-white text-white hover:bg-white hover:text-primary">
              Download Corporate Brochure
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}