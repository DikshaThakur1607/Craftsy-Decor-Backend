import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Heart, ShoppingBag, Menu, LogOut, User } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { CartDrawer } from "./CartDrawer";
import { useCart } from "./CartContext";
import { authService } from "../utils/auth-mock";
import logo from "figma:asset/64491cc878de21a2e273dd529cb89826fdb839c6.png";

interface HeaderProps {
  onLogout?: () => void;
}

export function Header({ onLogout }: HeaderProps) {
  const { state } = useCart();
  const user = authService.getUser();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'start',
        inline: 'nearest'
      });
    }
  };

  return (
    <header className="bg-white shadow-sm border-b border-muted sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center hover:opacity-80 transition-opacity"
          >
            <img 
              src={logo} 
              alt="Craftsy Decor - Where every piece tells a story"
              className="h-12 w-auto"
            />
          </button>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('products')}
              className="text-foreground hover:text-primary transition-colors"
            >
              Products
            </button>
            <button 
              onClick={() => scrollToSection('artisans')}
              className="text-foreground hover:text-primary transition-colors"
            >
              Our Artisans
            </button>
            <button 
              onClick={() => scrollToSection('sustainability')}
              className="text-foreground hover:text-primary transition-colors"
            >
              Sustainability
            </button>
            <button 
              onClick={() => scrollToSection('corporate')}
              className="text-foreground hover:text-primary transition-colors"
            >
              Corporate
            </button>
            <button 
              onClick={() => scrollToSection('subscription')}
              className="text-foreground hover:text-primary transition-colors"
            >
              Subscription
            </button>
          </nav>

          {/* Actions */}
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm" className="hidden sm:flex">
              <Heart className="w-4 h-4 mr-2" />
              Wishlist
            </Button>
            <CartDrawer>
              <Button size="sm" className="relative">
                <ShoppingBag className="w-4 h-4 mr-2" />
                Cart
                {state.totalItems > 0 && (
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
                  >
                    {state.totalItems}
                  </Badge>
                )}
              </Button>
            </CartDrawer>
            
            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="hidden sm:flex">
                  <User className="w-4 h-4 mr-2" />
                  {user?.user_metadata?.name || user?.email || 'Account'}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-2 py-1.5 text-sm text-muted-foreground">
                  {user?.email}
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer">
                  <User className="w-4 h-4 mr-2" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">
                  <Heart className="w-4 h-4 mr-2" />
                  Wishlist
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  className="cursor-pointer text-destructive focus:text-destructive"
                  onClick={onLogout}
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <Button variant="ghost" size="sm" className="md:hidden">
              <Menu className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}