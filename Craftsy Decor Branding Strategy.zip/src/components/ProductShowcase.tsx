import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { QrCode, Heart, Check } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useCart } from "./CartContext";
import { useState } from "react";
import { toast } from "sonner@2.0.3";

const products = [
  {
    id: 1,
    name: "Handwoven Bamboo Planters",
    price: "₹1,299",
    priceNumeric: 1299,
    artisan: "Ravi Kumar, Assam",
    category: "Eco-Friendly",
    image: "https://images.unsplash.com/photo-1643185720431-9c050eebbc9a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXN0YWluYWJsZSUyMGJhbWJvbyUyMGRlY29yJTIwaXRlbXN8ZW58MXx8fHwxNzU4MDMxNDAxfDA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 2,
    name: "Upcycled Jute Wall Art",
    price: "₹899",
    priceNumeric: 899,
    artisan: "Maya Devi, Rajasthan",
    category: "Upcycled",
    image: "https://images.unsplash.com/photo-1636483021999-c75dd25fc8fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1cGN5Y2xlZCUyMGhvbWUlMjBhY2Nlc3NvcmllcyUyMGhhbmRjcmFmdGVkfGVufDF8fHx8MTc1ODAzMTQwMnww&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 3,
    name: "Ceramic Plant Pots Set",
    price: "₹1,599",
    priceNumeric: 1599,
    artisan: "Anjali Sharma, Kerala",
    category: "Handmade",
    image: "https://images.unsplash.com/photo-1708368952731-db40e6a86d21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbWFkZSUyMGhvbWUlMjBkZWNvciUyMHBvdHRlcnklMjBzdXN0YWluYWJsZXxlbnwxfHx8fDE3NTgwMzE0MDB8MA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    id: 4,
    name: "Natural Home Garden Set",
    price: "₹2,199",
    priceNumeric: 2199,
    artisan: "Arjun Patel, Gujarat",
    category: "Sustainable",
    image: "https://images.unsplash.com/photo-1756266749980-eb11d4a8194c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlY28lMjBmcmllbmRseSUyMGhvbWUlMjBkZWNvcmF0aW9uJTIwcGxhbnRzfGVufDF8fHx8MTc1ODAzMTQwMXww&ixlib=rb-4.1.0&q=80&w=1080"
  },
];

export function ProductShowcase() {
  const { addItem, state } = useCart();
  const [addedItems, setAddedItems] = useState<Set<number>>(new Set());

  const handleAddToCart = (product: typeof products[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      priceNumeric: product.priceNumeric,
      artisan: product.artisan,
      category: product.category,
      image: product.image
    });

    // Show temporary success state
    setAddedItems(prev => new Set(prev.add(product.id)));
    setTimeout(() => {
      setAddedItems(prev => {
        const newSet = new Set(prev);
        newSet.delete(product.id);
        return newSet;
      });
    }, 2000);

    // Show toast notification
    toast.success(`${product.name} added to cart!`, {
      description: `by ${product.artisan}`,
      duration: 3000,
    });
  };

  const isInCart = (productId: number) => {
    return state.items.some(item => item.id === productId);
  };

  const wasRecentlyAdded = (productId: number) => {
    return addedItems.has(productId);
  };

  return (
    <section id="products" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">
            Curated with Care
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Every piece tells a story of skilled craftsmanship, sustainability, and social impact.
            Discover décor that transforms spaces and empowers communities.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="group overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative overflow-hidden">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-3 left-3">
                  <Badge variant="secondary" className="bg-white/90 text-foreground">
                    {product.category}
                  </Badge>
                </div>
                <div className="absolute top-3 right-3 flex space-x-2">
                  <Button size="sm" variant="secondary" className="w-8 h-8 p-0 bg-white/90 hover:bg-white">
                    <Heart className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="secondary" className="w-8 h-8 p-0 bg-white/90 hover:bg-white">
                    <QrCode className="w-4 h-4" />
                  </Button>
                </div>
                {isInCart(product.id) && (
                  <div className="absolute bottom-3 left-3">
                    <Badge className="bg-primary text-white">
                      In Cart
                    </Badge>
                  </div>
                )}
              </div>
              
              <CardContent className="p-4">
                <h3 className="mb-2 text-foreground">{product.name}</h3>
                <p className="text-sm text-muted-foreground mb-2">by {product.artisan}</p>
                <div className="flex items-center justify-between">
                  <span className="text-lg text-primary">{product.price}</span>
                  <Button 
                    size="sm" 
                    variant={wasRecentlyAdded(product.id) ? "default" : "outline"}
                    onClick={() => handleAddToCart(product)}
                    disabled={wasRecentlyAdded(product.id)}
                    className={wasRecentlyAdded(product.id) ? "bg-green-600 hover:bg-green-600" : ""}
                  >
                    {wasRecentlyAdded(product.id) ? (
                      <>
                        <Check className="w-4 h-4 mr-1" />
                        Added
                      </>
                    ) : (
                      "Add to Cart"
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline">
            View All Products
          </Button>
        </div>
      </div>
    </section>
  );
}