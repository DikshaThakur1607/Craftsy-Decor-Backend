import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Mail, Phone, MapPin, MessageCircle } from "lucide-react";

export function ContactSection() {
  return (
    <section className="py-16 bg-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">
            Let's Create Something Beautiful Together
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Have a custom request? Want to partner with us? Or simply want to learn more about our artisans? 
            We'd love to hear from you.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card className="bg-white">
              <CardHeader>
                <h3 className="text-xl text-foreground">Send us a message</h3>
                <p className="text-sm text-muted-foreground">
                  Fill out the form below and we'll get back to you within 24 hours.
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-foreground mb-2 block">Name</label>
                    <Input placeholder="Your full name" />
                  </div>
                  <div>
                    <label className="text-sm text-foreground mb-2 block">Email</label>
                    <Input type="email" placeholder="your@email.com" />
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-foreground mb-2 block">Phone</label>
                    <Input placeholder="+91 98765 43210" />
                  </div>
                  <div>
                    <label className="text-sm text-foreground mb-2 block">Inquiry Type</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select inquiry type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="custom">Custom Order</SelectItem>
                        <SelectItem value="corporate">Corporate Partnership</SelectItem>
                        <SelectItem value="artisan">Artisan Collaboration</SelectItem>
                        <SelectItem value="wholesale">Wholesale Inquiry</SelectItem>
                        <SelectItem value="support">Customer Support</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <label className="text-sm text-foreground mb-2 block">Message</label>
                  <Textarea 
                    placeholder="Tell us about your project, requirements, or any questions you have..."
                    rows={4}
                  />
                </div>

                <Button size="lg" className="w-full bg-primary hover:bg-primary/90">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Send Message
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Contact Info */}
          <div className="space-y-6">
            <Card className="bg-white">
              <CardContent className="p-6">
                <h3 className="text-lg mb-4 text-foreground">Get in Touch</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Mail className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm text-foreground">Email</p>
                      <p className="text-sm text-muted-foreground">hello@craftsy-decor.com</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Phone className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm text-foreground">Phone</p>
                      <p className="text-sm text-muted-foreground">+91 98765 43210</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm text-foreground">Address</p>
                      <p className="text-sm text-muted-foreground">123 Craft Street, New Delhi, India</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-primary text-white">
              <CardContent className="p-6">
                <h3 className="text-lg mb-3">Custom Orders</h3>
                <p className="text-sm text-white/90 mb-4">
                  Looking for something specific? Our artisans can create custom pieces tailored to your vision.
                </p>
                <Button variant="secondary" className="w-full bg-white text-primary hover:bg-white/90">
                  Request Custom Quote
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-accent">
              <CardContent className="p-6">
                <h3 className="text-lg mb-3 text-foreground">Response Time</h3>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>• General inquiries: 24 hours</p>
                  <p>• Custom orders: 2-3 business days</p>
                  <p>• Corporate partnerships: 1 week</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}