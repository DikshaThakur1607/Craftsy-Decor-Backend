import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "./ui/sheet";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { useCart } from "./CartContext";
import { ShoppingBag, Plus, Minus, Trash2, X } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface CartDrawerProps {
  children: React.ReactNode;
}

export function CartDrawer({ children }: CartDrawerProps) {
  const { state, updateQuantity, removeItem, clearCart } = useCart();

  const handleQuantityChange = (id: number, change: number) => {
    const item = state.items.find(item => item.id === id);
    if (item) {
      updateQuantity(id, item.quantity + change);
    }
  };

  return (
    <Sheet>
      <SheetTrigger asChild>
        {children}
      </SheetTrigger>
      <SheetContent className="w-full sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5" />
            Shopping Cart
            {state.totalItems > 0 && (
              <Badge variant="secondary" className="bg-primary text-white">
                {state.totalItems}
              </Badge>
            )}
          </SheetTitle>
          <SheetDescription>
            {state.totalItems === 0 
              ? "Your cart is empty" 
              : `${state.totalItems} item${state.totalItems > 1 ? 's' : ''} in your cart`
            }
          </SheetDescription>
        </SheetHeader>

        <div className="flex flex-col h-full">
          {state.items.length === 0 ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <ShoppingBag className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Your cart is empty</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Add some beautiful handcrafted items to get started
                </p>
              </div>
            </div>
          ) : (
            <>
              {/* Cart Items */}
              <div className="flex-1 overflow-y-auto py-6">
                <div className="space-y-4">
                  {state.items.map((item) => (
                    <div key={item.id} className="flex gap-3 pb-4">
                      <div className="w-16 h-16 rounded-lg overflow-hidden bg-muted">
                        <ImageWithFallback
                          src={item.image}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm text-foreground truncate">{item.name}</h4>
                        <p className="text-xs text-muted-foreground">by {item.artisan}</p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-sm text-primary">{item.price}</span>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="w-6 h-6 p-0"
                              onClick={() => handleQuantityChange(item.id, -1)}
                            >
                              <Minus className="w-3 h-3" />
                            </Button>
                            <span className="text-sm w-8 text-center">{item.quantity}</span>
                            <Button
                              size="sm"
                              variant="outline"
                              className="w-6 h-6 p-0"
                              onClick={() => handleQuantityChange(item.id, 1)}
                            >
                              <Plus className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="w-6 h-6 p-0 text-destructive hover:text-destructive"
                              onClick={() => removeItem(item.id)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Cart Summary */}
              <div className="border-t pt-4 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-base">Total ({state.totalItems} items)</span>
                  <span className="text-lg text-primary">₹{state.totalPrice.toLocaleString()}</span>
                </div>
                
                <div className="space-y-2">
                  <Button className="w-full bg-primary hover:bg-primary/90" size="lg">
                    Proceed to Checkout
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={clearCart}
                    disabled={state.items.length === 0}
                  >
                    Clear Cart
                  </Button>
                </div>
                
                <div className="text-xs text-muted-foreground text-center">
                  <p>🌱 Free shipping on orders above ₹1,500</p>
                  <p>📦 Carbon-neutral delivery in 3-5 days</p>
                </div>
              </div>
            </>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}