import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Quote, MapPin, Calendar } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const artisans = [
  {
    id: 1,
    name: "Priya Mehta",
    location: "Delhi",
    craft: "Ceramic Pottery",
    story: "After losing her vision at age 25, Priya discovered pottery as her new voice. Today, her tactile masterpieces bring joy to homes across India.",
    yearsOfExperience: "8 years",
    image: "https://images.unsplash.com/photo-1669905783510-1d711851615a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB3b21hbiUyMHBvdHRlciUyMGFydGlzYW4lMjBwb3J0cmFpdCUyMGZhY2UlMjBjbG9zZXVwfGVufDF8fHx8MTc1ODAzNDgxMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    id: 2,
    name: "Ravi Kumar",
    location: "Assam",
    craft: "Bamboo Weaving",
    story: "A third-generation bamboo artisan, Ravi is preserving traditional techniques while creating modern designs that bridge heritage and contemporary living.",
    yearsOfExperience: "15 years",
    image: "https://images.unsplash.com/photo-1585718540843-11b15b63a18f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBtYW4lMjBjcmFmdHNtYW4lMjBwb3J0cmFpdCUyMGZhY2UlMjBjbG9zZXVwJTIwYXJ0aXNhbnxlbnwxfHx8fDE3NTgwMzQ4MTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    id: 3,
    name: "Maya Devi",
    location: "Rajasthan",
    craft: "Upcycled Textiles",
    story: "Maya transforms waste fabrics into beautiful wall art, proving that sustainability and beauty go hand in hand. Her work supports 20 women in her village.",
    yearsOfExperience: "12 years",
    image: "https://images.unsplash.com/photo-1523512090443-2d7df8b40358?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB3b21hbiUyMHRleHRpbGUlMjB3b3JrZXIlMjBwb3J0cmFpdCUyMGNsb3NldXAlMjBzbWlsaW5nfGVufDF8fHx8MTc1ODAzNDgxN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  }
];

export function ArtisanStories() {
  return (
    <section id="artisans" className="py-16 bg-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">
            Meet the Makers
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Behind every beautiful piece is a skilled artisan with a unique story. 
            Discover the hands and hearts that craft your home décor.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {artisans.map((artisan) => (
            <Card key={artisan.id} className="bg-white overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <ImageWithFallback
                  src={artisan.image}
                  alt={`${artisan.name} - Artisan Portrait`}
                  className="w-full h-64 object-cover object-top"
                />
                <div className="absolute top-4 left-4 bg-primary/90 backdrop-blur-sm text-white px-3 py-1 rounded-full text-xs shadow-lg">
                  {artisan.craft}
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent" />
              </div>
              
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl text-foreground mb-1">{artisan.name}</h3>
                    <div className="flex items-center text-sm text-muted-foreground mb-2">
                      <MapPin className="w-4 h-4 mr-1" />
                      {artisan.location}
                    </div>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4 mr-1" />
                      {artisan.yearsOfExperience}
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="relative mb-4">
                  <Quote className="w-5 h-5 text-primary/30 absolute -top-2 -left-1" />
                  <p className="text-sm text-muted-foreground pl-4 italic">
                    "{artisan.story}"
                  </p>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  View {artisan.name}'s Collection
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Support More Artisans
          </Button>
        </div>
      </div>
    </section>
  );
}