import { Button } from "./ui/button";
import { ArrowRight, Recycle, Users } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-secondary to-accent py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl text-foreground leading-tight">
                Handmade with Heart,
                <br />
                <span className="text-primary">Delivered with Care</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-lg">
                Transform your home with sustainable, handcrafted décor that tells a story. 
                Every purchase empowers artisan communities and supports eco-friendly living.
              </p>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8">
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-primary" />
                <span className="text-sm">500+ Artisans Empowered</span>
              </div>
              <div className="flex items-center space-x-2">
                <Recycle className="w-5 h-5 text-primary" />
                <span className="text-sm">100% Eco-Friendly</span>
              </div>
            </div>

            {/* CTA */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                className="bg-primary hover:bg-primary/90"
                onClick={() => {
                  const element = document.getElementById('products');
                  if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }
                }}
              >
                Shop Collection
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => {
                  const element = document.getElementById('artisans');
                  if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }
                }}
              >
                Meet Our Artisans
              </Button>
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="relative overflow-hidden rounded-2xl shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1708368952731-db40e6a86d21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbWFkZSUyMGhvbWUlMjBkZWNvciUyMHBvdHRlcnklMjBzdXN0YWluYWJsZXxlbnwxfHx8fDE3NTgwMzE0MDB8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Handmade pottery and sustainable home decor"
                className="w-full h-96 lg:h-[500px] object-cover"
              />
              <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2">
                <p className="text-sm font-medium text-foreground">Handcrafted Pottery</p>
                <p className="text-xs text-muted-foreground">by Priya, Delhi</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}