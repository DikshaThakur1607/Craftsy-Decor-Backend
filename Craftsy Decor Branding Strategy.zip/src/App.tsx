import { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { ProductShowcase } from "./components/ProductShowcase";
import { ArtisanStories } from "./components/ArtisanStories";
import { SustainabilitySection } from "./components/SustainabilitySection";
import { CorporateSection } from "./components/CorporateSection";
import { SubscriptionSection } from "./components/SubscriptionSection";
import { ContactSection } from "./components/ContactSection";
import { Footer } from "./components/Footer";
import { LoginPage } from "./components/LoginPage";
import { CartProvider } from "./components/CartContext";
import { Toaster } from "./components/ui/sonner";
import { authService } from "./utils/auth-mock";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      const { user, session } = await authService.getCurrentSession();
      setIsAuthenticated(!!(user && session));
    } catch (error) {
      console.error('Auth check failed:', error);
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoginSuccess = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = async () => {
    try {
      await authService.signOut();
      setIsAuthenticated(false);
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading Craftsy Decor...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <>
        <LoginPage onLoginSuccess={handleLoginSuccess} />
        <Toaster position="top-right" />
      </>
    );
  }

  return (
    <CartProvider>
      <div className="min-h-screen bg-background">
        <Header onLogout={handleLogout} />
        <main>
          <Hero />
          <ProductShowcase />
          <ArtisanStories />
          <SustainabilitySection />
          <CorporateSection />
          <SubscriptionSection />
          <ContactSection />
        </main>
        <Footer />
        <Toaster position="top-right" />
      </div>
    </CartProvider>
  );
}