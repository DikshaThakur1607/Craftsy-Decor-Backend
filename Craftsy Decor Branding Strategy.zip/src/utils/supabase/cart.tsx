import { authService } from "./auth";
import { projectId, publicAnonKey } from "./info";

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  category?: string;
}

export interface Cart {
  items: CartItem[];
  total: number;
}

export class CartService {
  private static instance: CartService;
  private cart: Cart = { items: [], total: 0 };
  private listeners: Array<(cart: Cart) => void> = [];

  static getInstance(): CartService {
    if (!CartService.instance) {
      CartService.instance = new CartService();
    }
    return CartService.instance;
  }

  subscribe(listener: (cart: Cart) => void) {
    this.listeners.push(listener);
    return () => {
      const index = this.listeners.indexOf(listener);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  private notifyListeners() {
    this.listeners.forEach(listener => listener(this.cart));
  }

  private async makeRequest(path: string, options: RequestInit = {}) {
    const token = authService.getAccessToken();
    
    const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-eeb1996f${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token ? `Bearer ${token}` : `Bearer ${publicAnonKey}`,
        ...options.headers
      }
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Request failed');
    }

    return response.json();
  }

  async loadCart(): Promise<void> {
    try {
      if (!authService.isAuthenticated()) {
        // Load from localStorage for non-authenticated users
        const localCart = localStorage.getItem('craftsy-cart');
        if (localCart) {
          this.cart = JSON.parse(localCart);
          this.notifyListeners();
        }
        return;
      }

      const data = await this.makeRequest('/cart');
      this.cart = data.cart;
      this.notifyListeners();

    } catch (error) {
      console.error('Error loading cart:', error);
      // Fallback to localStorage
      const localCart = localStorage.getItem('craftsy-cart');
      if (localCart) {
        this.cart = JSON.parse(localCart);
        this.notifyListeners();
      }
    }
  }

  async saveCart(): Promise<void> {
    try {
      // Always save to localStorage
      localStorage.setItem('craftsy-cart', JSON.stringify(this.cart));

      // Save to server if authenticated
      if (authService.isAuthenticated()) {
        await this.makeRequest('/cart', {
          method: 'POST',
          body: JSON.stringify(this.cart)
        });
      }

    } catch (error) {
      console.error('Error saving cart:', error);
    }
  }

  getCart(): Cart {
    return this.cart;
  }

  addItem(item: CartItem): void {
    const existingItemIndex = this.cart.items.findIndex(
      cartItem => cartItem.id === item.id
    );

    if (existingItemIndex > -1) {
      this.cart.items[existingItemIndex].quantity += item.quantity;
    } else {
      this.cart.items.push(item);
    }

    this.calculateTotal();
    this.notifyListeners();
    this.saveCart();
  }

  removeItem(itemId: string): void {
    this.cart.items = this.cart.items.filter(item => item.id !== itemId);
    this.calculateTotal();
    this.notifyListeners();
    this.saveCart();
  }

  updateQuantity(itemId: string, quantity: number): void {
    const itemIndex = this.cart.items.findIndex(item => item.id === itemId);
    if (itemIndex > -1) {
      if (quantity <= 0) {
        this.removeItem(itemId);
      } else {
        this.cart.items[itemIndex].quantity = quantity;
        this.calculateTotal();
        this.notifyListeners();
        this.saveCart();
      }
    }
  }

  async clearCart(): Promise<void> {
    this.cart = { items: [], total: 0 };
    
    // Clear from localStorage
    localStorage.removeItem('craftsy-cart');

    // Clear from server if authenticated
    if (authService.isAuthenticated()) {
      try {
        await this.makeRequest('/cart', {
          method: 'DELETE'
        });
      } catch (error) {
        console.error('Error clearing cart on server:', error);
      }
    }

    this.notifyListeners();
  }

  private calculateTotal(): void {
    this.cart.total = this.cart.items.reduce(
      (total, item) => total + (item.price * item.quantity),
      0
    );
  }

  getItemCount(): number {
    return this.cart.items.reduce((count, item) => count + item.quantity, 0);
  }

  async syncCartAfterLogin(): Promise<void> {
    try {
      // Get local cart
      const localCart = localStorage.getItem('craftsy-cart');
      let localCartData: Cart = { items: [], total: 0 };
      
      if (localCart) {
        localCartData = JSON.parse(localCart);
      }

      // Get server cart
      const serverData = await this.makeRequest('/cart');
      const serverCart: Cart = serverData.cart;

      // Merge carts (prioritize local cart for conflicts)
      const mergedItems: CartItem[] = [...localCartData.items];
      
      serverCart.items.forEach(serverItem => {
        const existingIndex = mergedItems.findIndex(item => item.id === serverItem.id);
        if (existingIndex === -1) {
          mergedItems.push(serverItem);
        }
        // If item exists in local cart, keep local version (user was shopping offline)
      });

      this.cart = { items: mergedItems, total: 0 };
      this.calculateTotal();

      // Save merged cart to server
      await this.saveCart();
      this.notifyListeners();

    } catch (error) {
      console.error('Error syncing cart after login:', error);
    }
  }
}

export const cartService = CartService.getInstance();