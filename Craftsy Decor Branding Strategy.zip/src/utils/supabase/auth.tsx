import { supabase } from "./client";
import { projectId, publicAnonKey } from "./info";

interface SignUpData {
  email: string;
  password: string;
  name: string;
}

interface SignInData {
  email: string;
  password: string;
}

interface AuthResponse {
  user?: any;
  session?: any;
  error?: string;
}

export class AuthService {
  private static instance: AuthService;
  private currentUser: any = null;
  private currentSession: any = null;

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  async signUp({ email, password, name }: SignUpData): Promise<AuthResponse> {
    try {
      // First create user via server endpoint
      const serverResponse = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-eeb1996f/auth/signup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({ email, password, name })
      });

      const serverData = await serverResponse.json();

      if (!serverResponse.ok) {
        return { error: serverData.error || 'Signup failed' };
      }

      // Then sign in the user
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        return { error: error.message };
      }

      this.currentUser = data.user;
      this.currentSession = data.session;

      return { user: data.user, session: data.session };

    } catch (error) {
      console.error('Signup error:', error);
      return { error: 'Network error during signup' };
    }
  }

  async signIn({ email, password }: SignInData): Promise<AuthResponse> {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        return { error: error.message };
      }

      this.currentUser = data.user;
      this.currentSession = data.session;

      return { user: data.user, session: data.session };

    } catch (error) {
      console.error('Signin error:', error);
      return { error: 'Network error during signin' };
    }
  }

  async signInWithGoogle(): Promise<AuthResponse> {
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
      });

      if (error) {
        return { error: error.message };
      }

      return { user: data.user, session: data.session };

    } catch (error) {
      console.error('Google signin error:', error);
      return { error: 'Network error during Google signin' };
    }
  }

  async signOut(): Promise<{ error?: string }> {
    try {
      const { error } = await supabase.auth.signOut();
      
      this.currentUser = null;
      this.currentSession = null;

      if (error) {
        return { error: error.message };
      }

      return {};

    } catch (error) {
      console.error('Signout error:', error);
      return { error: 'Network error during signout' };
    }
  }

  async getCurrentSession(): Promise<AuthResponse> {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();

      if (error) {
        return { error: error.message };
      }

      this.currentSession = session;
      this.currentUser = session?.user || null;

      return { user: session?.user, session };

    } catch (error) {
      console.error('Get session error:', error);
      return { error: 'Network error getting session' };
    }
  }

  getUser() {
    return this.currentUser;
  }

  getSession() {
    return this.currentSession;
  }

  isAuthenticated(): boolean {
    return !!this.currentSession && !!this.currentUser;
  }

  getAccessToken(): string | null {
    return this.currentSession?.access_token || null;
  }
}

export const authService = AuthService.getInstance();