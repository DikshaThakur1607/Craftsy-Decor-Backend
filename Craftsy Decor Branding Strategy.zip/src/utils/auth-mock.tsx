// Mock auth service for development without backend dependencies
interface User {
  id: string;
  email: string;
  user_metadata?: {
    name?: string;
  };
}

interface Session {
  access_token: string;
  user: User;
}

interface AuthResponse {
  user?: User;
  session?: Session;
  error?: string;
}

interface SignUpData {
  email: string;
  password: string;
  name: string;
}

interface SignInData {
  email: string;
  password: string;
}

class MockAuthService {
  private static instance: MockAuthService;
  private currentUser: User | null = null;
  private currentSession: Session | null = null;

  static getInstance(): MockAuthService {
    if (!MockAuthService.instance) {
      MockAuthService.instance = new MockAuthService();
    }
    return MockAuthService.instance;
  }

  async signUp({ email, password, name }: SignUpData): Promise<AuthResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Mock validation
    if (!email || !password || !name) {
      return { error: "All fields are required" };
    }

    if (!email.includes('@')) {
      return { error: "Please enter a valid email address" };
    }

    if (password.length < 6) {
      return { error: "Password must be at least 6 characters" };
    }

    // Create mock user
    const user: User = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      user_metadata: { name }
    };

    const session: Session = {
      access_token: Math.random().toString(36).substr(2, 20),
      user
    };

    this.currentUser = user;
    this.currentSession = session;

    // Store in localStorage
    localStorage.setItem('craftsy-auth', JSON.stringify({ user, session }));

    return { user, session };
  }

  async signIn({ email, password }: SignInData): Promise<AuthResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Mock validation
    if (!email || !password) {
      return { error: "Email and password are required" };
    }

    if (!email.includes('@')) {
      return { error: "Please enter a valid email address" };
    }

    // For demo purposes, accept any valid email/password combo
    const user: User = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      user_metadata: { name: email.split('@')[0] }
    };

    const session: Session = {
      access_token: Math.random().toString(36).substr(2, 20),
      user
    };

    this.currentUser = user;
    this.currentSession = session;

    // Store in localStorage
    localStorage.setItem('craftsy-auth', JSON.stringify({ user, session }));

    return { user, session };
  }

  async signInWithGoogle(): Promise<AuthResponse> {
    return { error: "Google sign-in requires backend setup. Please use email/password for now." };
  }

  async signOut(): Promise<{ error?: string }> {
    this.currentUser = null;
    this.currentSession = null;
    localStorage.removeItem('craftsy-auth');
    return {};
  }

  async getCurrentSession(): Promise<AuthResponse> {
    try {
      const stored = localStorage.getItem('craftsy-auth');
      if (stored) {
        const { user, session } = JSON.parse(stored);
        this.currentUser = user;
        this.currentSession = session;
        return { user, session };
      }
    } catch (error) {
      console.error('Error loading session:', error);
    }

    return { user: null, session: null };
  }

  getUser(): User | null {
    return this.currentUser;
  }

  getSession(): Session | null {
    return this.currentSession;
  }

  isAuthenticated(): boolean {
    return !!(this.currentSession && this.currentUser);
  }

  getAccessToken(): string | null {
    return this.currentSession?.access_token || null;
  }
}

export const authService = MockAuthService.getInstance();