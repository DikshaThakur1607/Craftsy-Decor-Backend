// Mock cart service for development without backend dependencies
export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  category?: string;
}

export interface Cart {
  items: CartItem[];
  total: number;
}

class MockCartService {
  private static instance: MockCartService;
  private cart: Cart = { items: [], total: 0 };
  private listeners: Array<(cart: Cart) => void> = [];

  static getInstance(): MockCartService {
    if (!MockCartService.instance) {
      MockCartService.instance = new MockCartService();
    }
    return MockCartService.instance;
  }

  subscribe(listener: (cart: Cart) => void) {
    this.listeners.push(listener);
    return () => {
      const index = this.listeners.indexOf(listener);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  private notifyListeners() {
    this.listeners.forEach(listener => listener(this.cart));
  }

  async loadCart(): Promise<void> {
    try {
      const localCart = localStorage.getItem('craftsy-cart');
      if (localCart) {
        this.cart = JSON.parse(localCart);
        this.notifyListeners();
      }
    } catch (error) {
      console.error('Error loading cart:', error);
    }
  }

  private async saveCart(): Promise<void> {
    try {
      localStorage.setItem('craftsy-cart', JSON.stringify(this.cart));
    } catch (error) {
      console.error('Error saving cart:', error);
    }
  }

  getCart(): Cart {
    return this.cart;
  }

  addItem(item: CartItem): void {
    const existingItemIndex = this.cart.items.findIndex(
      cartItem => cartItem.id === item.id
    );

    if (existingItemIndex > -1) {
      this.cart.items[existingItemIndex].quantity += item.quantity;
    } else {
      this.cart.items.push(item);
    }

    this.calculateTotal();
    this.notifyListeners();
    this.saveCart();
  }

  removeItem(itemId: string): void {
    this.cart.items = this.cart.items.filter(item => item.id !== itemId);
    this.calculateTotal();
    this.notifyListeners();
    this.saveCart();
  }

  updateQuantity(itemId: string, quantity: number): void {
    const itemIndex = this.cart.items.findIndex(item => item.id === itemId);
    if (itemIndex > -1) {
      if (quantity <= 0) {
        this.removeItem(itemId);
      } else {
        this.cart.items[itemIndex].quantity = quantity;
        this.calculateTotal();
        this.notifyListeners();
        this.saveCart();
      }
    }
  }

  async clearCart(): Promise<void> {
    this.cart = { items: [], total: 0 };
    localStorage.removeItem('craftsy-cart');
    this.notifyListeners();
  }

  private calculateTotal(): void {
    this.cart.total = this.cart.items.reduce(
      (total, item) => total + (item.price * item.quantity),
      0
    );
  }

  getItemCount(): number {
    return this.cart.items.reduce((count, item) => count + item.quantity, 0);
  }

  async syncCartAfterLogin(): Promise<void> {
    // In mock version, just load from localStorage
    await this.loadCart();
  }
}

export const cartService = MockCartService.getInstance();