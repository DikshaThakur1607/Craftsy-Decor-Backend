import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "@supabase/supabase-js";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Create Supabase client with service role key for server operations
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Auth helper function
async function getAuthenticatedUser(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  if (!accessToken) {
    return null;
  }

  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  if (error || !user) {
    return null;
  }

  return user;
}

// Health check endpoint
app.get("/make-server-eeb1996f/health", (c) => {
  return c.json({ status: "ok" });
});

// Authentication Routes
app.post("/make-server-eeb1996f/auth/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    if (!email || !password || !name) {
      return c.json({ error: "Email, password, and name are required" }, 400);
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ 
      user: data.user,
      message: "User created successfully" 
    });

  } catch (error) {
    console.log('Signup server error:', error);
    return c.json({ error: "Internal server error during signup" }, 500);
  }
});

app.post("/make-server-eeb1996f/auth/signin", async (c) => {
  try {
    const { email, password } = await c.req.json();

    if (!email || !password) {
      return c.json({ error: "Email and password are required" }, 400);
    }

    // Note: signInWithPassword should be called from the frontend
    // This endpoint is just for validation/custom logic if needed
    return c.json({ message: "Use frontend signin" });

  } catch (error) {
    console.log('Signin server error:', error);
    return c.json({ error: "Internal server error during signin" }, 500);
  }
});

// Cart Routes
app.get("/make-server-eeb1996f/cart", async (c) => {
  try {
    const user = await getAuthenticatedUser(c.req.raw);
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const cartKey = `cart:${user.id}`;
    const cartData = await kv.get(cartKey);
    
    return c.json({ 
      cart: cartData ? JSON.parse(cartData) : { items: [], total: 0 }
    });

  } catch (error) {
    console.log('Get cart error:', error);
    return c.json({ error: "Failed to retrieve cart" }, 500);
  }
});

app.post("/make-server-eeb1996f/cart", async (c) => {
  try {
    const user = await getAuthenticatedUser(c.req.raw);
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { items, total } = await c.req.json();

    if (!Array.isArray(items)) {
      return c.json({ error: "Invalid cart data: items must be an array" }, 400);
    }

    const cartKey = `cart:${user.id}`;
    const cartData = JSON.stringify({ 
      items, 
      total: total || 0,
      updatedAt: new Date().toISOString()
    });

    await kv.set(cartKey, cartData);

    return c.json({ 
      message: "Cart saved successfully",
      cart: { items, total }
    });

  } catch (error) {
    console.log('Save cart error:', error);
    return c.json({ error: "Failed to save cart" }, 500);
  }
});

app.delete("/make-server-eeb1996f/cart", async (c) => {
  try {
    const user = await getAuthenticatedUser(c.req.raw);
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const cartKey = `cart:${user.id}`;
    await kv.del(cartKey);

    return c.json({ message: "Cart cleared successfully" });

  } catch (error) {
    console.log('Clear cart error:', error);
    return c.json({ error: "Failed to clear cart" }, 500);
  }
});

// User Profile Routes
app.get("/make-server-eeb1996f/profile", async (c) => {
  try {
    const user = await getAuthenticatedUser(c.req.raw);
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    return c.json({ 
      user: {
        id: user.id,
        email: user.email,
        name: user.user_metadata?.name || '',
        created_at: user.created_at
      }
    });

  } catch (error) {
    console.log('Get profile error:', error);
    return c.json({ error: "Failed to retrieve profile" }, 500);
  }
});

Deno.serve(app.fetch);